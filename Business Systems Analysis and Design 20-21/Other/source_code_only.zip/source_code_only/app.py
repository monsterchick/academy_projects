from flask import Flask, render_template, redirect, url_for, request

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired, EqualTo

from werkzeug.security import generate_password_hash
from werkzeug.security import check_password_hash

from flask_login import LoginManager, UserMixin, current_user
from flask_login import logout_user, login_user, login_required

import uuid

app = Flask(__name__)  # create Flask application

app.secret_key = 'abc'  # set key

login_manager = LoginManager()  # login management object
login_manager.init_app(app)  # Initialize the application
login_manager.session_protection = 'strong'
login_manager.login_view = 'login'  # Set user login view function

# user data
USERS = [
    {
        "id": 1,
        "name": 'operate_member',
        "password": generate_password_hash('111')
    },
    {
        "id": 2,
        "name": 'resiliency_member',
        "password": generate_password_hash('222')
    },
    {
        "id": 2,
        "name": 'application_member',
        "password": generate_password_hash('333')
    }
]


def create_user(user_name, password):
    """create users"""
    user = {
        "name": user_name,
        "password": generate_password_hash(password),
        "id": uuid.uuid4()
    }
    USERS.append(user)


def get_user(user_name):
    """get user records by user name"""
    for user in USERS:
        if user.get("name") == user_name:
            return user
    return None


class LoginForm(FlaskForm):
    """login form"""
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])


class SignupForm(FlaskForm):
    """User registration form"""
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', [
        DataRequired(),
        EqualTo('confirm', message='The two passwords entered are inconsistent')
    ])
    confirm = PasswordField('confirm password')


class User(UserMixin):
    """user"""

    def __init__(self, user):
        self.username = user.get("name")
        self.password_hash = user.get("password")
        self.id = user.get("id")

    def verify_password(self, password):
        """password validation"""
        if self.password_hash is None:
            return False
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        """get user's ID"""
        return self.id

    @staticmethod
    def get(user_id):
        """Get user entity based on user ID"""
        if not user_id:
            return None
        for user in USERS:
            if user.get('id') == user_id:
                return User(user)
        return None


@login_manager.user_loader  # Define the method to get the logged-in user
def load_user(user_id):
    return User.get(user_id)


@app.route('/signup/', methods=('GET', 'POST'))  # sign up
def signup():
    form = SignupForm()
    emsg = None
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data

        user_info = get_user(user_name)  # get user info by username
        if user_info is None:
            create_user(user_name, password)  # Create a user if it does not exist
            return redirect(url_for("login"))  # go to login page after creating
        else:
            emsg = "username is exist"  # If the user already exists, give an error prompt
    return render_template('signup.html', form=form, emsg=emsg)


@app.route('/login/', methods=('GET', 'POST'))  # login
def login():
    form = LoginForm()
    emsg = None
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data
        user_info = get_user(user_name)
        if user_info is None:
            emsg = "Username or Password invalid."
        else:
            user = User(user_info)
            if user.verify_password(password):
                login_user(user)
                return redirect(request.args.get('next') or url_for('index'))
            else:
                emsg = "Username or Password invalid."
    return render_template('login.html', form=form, emsg=emsg)


@app.route('/')  # home page
@login_required  # to access the system, must login first
def index():
    return render_template('welcome.html', username=current_user.username)


@app.route('/logout')  # logout
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)